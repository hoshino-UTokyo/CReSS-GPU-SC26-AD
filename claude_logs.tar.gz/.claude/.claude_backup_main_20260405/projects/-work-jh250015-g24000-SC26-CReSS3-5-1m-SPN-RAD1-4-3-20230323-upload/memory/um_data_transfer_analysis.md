---
name: Unified Memory データ転送プロファイリング結果
description: nsysプロファイリングによるUnified Memoryページフォルト・データ転送の分析結果（2026-03-23）
type: project
---

## Unified Memory データ転送分析 (2026-03-23)

nsys profile（10step/50秒シミュレーション、1プロセス実行）で測定。

**Why:** `-gpu=managed`（Unified Memory）を使用しているため、明示的data directiveなしでCPU-GPU間のデータ転送がページフォルトベースで暗黙的に行われる。性能最適化のためにどこでどれだけ転送が発生しているか把握する必要がある。

**How to apply:** 今後の最適化（explicit data management、GPU-aware MPI、prefetch等）の優先順位を決める際の基礎データとして使用。

### 主要な発見

1. **ページフォルトは初期化フェーズ（最初の4秒）に集中、計算ループ中はゼロ**
   - 初期化: ~23.4 GB (614万回ページフォルト)、所要3.9秒
   - 計算ループ: ページフォルト発生なし

2. **初期化ページフォルトの原因: `setcst3d` (2.69秒/108回) と `setcst4d` (1.24秒/25回)**
   - 899×899×128の3D/4D配列を定数で初期化 → 全ページが初めてGPUアクセスされる

3. **明示的データ転送は極めて少量（計1 MB未満）**
   - `depsit.f90`: ckoe, pkoe (H→D, 0.4 MB)
   - `outmxn.f90`: maxeps等スカラ (双方向, スカラ値)
   - `adjstuv.f90`, `cloudcov.f90`, `fallblk.f90`: スカラ値のみ

4. **MPI通信ルーチン（shiftgx/gy, sethalo）にはGPU版なし**
   - 1プロセス実行ではMPI通信が実質不要のためページフォルト発生せず
   - **マルチプロセス実行時はハロー交換の度にCPUアクセス→ページフォルト発生が最大のボトルネック候補**

### プロファイルデータの場所
- nsys report: `test_real/profile_um.nsys-rep`
- nsys sqlite: `test_real/profile_um.sqlite`
- プロファイル用短縮config: `test_real/user_profile.conf` (etime=50秒)

### 計算フェーズ GPU カーネル Top 5
- gaussel (217): 48,860回, 0.659秒
- diverpiv (131): 800回, 0.538秒
- stepwi (396): 400回, 0.490秒
- stepuv (299): 400回, 0.424秒
- stepuv (313): 400回, 0.413秒
