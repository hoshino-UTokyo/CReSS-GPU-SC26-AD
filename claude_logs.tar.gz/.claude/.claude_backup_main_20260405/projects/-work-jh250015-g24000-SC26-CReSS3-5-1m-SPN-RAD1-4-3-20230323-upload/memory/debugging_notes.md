# GPU Debugging Notes

## Bug Pattern: Incomplete Benchmark Ports
Kernel_benchmark_gpu implementations sometimes only implement the "constant assignment" path
(e.g., bc=7 for phase speed), missing post-processing steps like clamping and scaling.
Variables are loaded but unused. Always verify that ALL operations from CPU code are present.

### phvuvw.f90 (Kernel 235) & phvbcuvw.f90 (Kernel 233)
Three missing operations:
1. exbvar/exbopt guard (determines which velocity component is processed)
2. mfcopt clamping (max/min with map factor arrays rmf8u/rmf8v/rmf)
3. dtsdb scaling (time step ratio: dts/dtb)

### phvuvw.f90 exbvar guard pattern:
- u: `exbvar(1:1).eq.'x'` (combined with exbopt check)
- v: `exbvar(2:2).eq.'x'`
- w: `exbvar(3:3).eq.'x'`

### phvbcuvw.f90 exbvar guard pattern:
- u west/east: `exbvar(1:1).eq.'-'`
- u south/north: `exbvar(1:1).eq.'-'.or.exbvar(1:1).eq.'+'`
- v west/east: `exbvar(2:2).eq.'-'.or.exbvar(2:2).eq.'+'`
- v south/north: `exbvar(2:2).eq.'-'`
- w all: `exbvar(3:3).eq.'-'`

### Clamping map factor patterns (with correct grid indices):
- u: west=max(-rmf8u(2,j)), east=min(rmf8u(**nim1**,j)); north=min(rmf8u(i,**njm2**))
- v: west=max(-rmf8v(2,j)), east=min(rmf8v(**nim2**,j)); north=min(rmf8v(i,**njm1**))
- w: west=max(-rmf(2,j)), east=min(rmf(**nim2**,j)); north=min(rmf(i,**njm2**))
- mpopt condition: west/east ne.5, south/north ne.0,ne.10
- NOTE: u uses nim1/njm2, v uses nim2/njm1, w uses nim2/njm2 (staggered grid difference)

### lbcw.f90 (Kernel 190)
- w-velocity boundary conditions: GPU had nk-2, should be nk-1

## Python Analysis Scripts
- `/tmp/compare_gpu_cpu_v2.py` - Systematic GPU vs CPU comparison with deep normalization
- `/tmp/check_private_vars.py` - Check OpenMP private variables in OpenACC code

## Remaining Known Issues
- turbuvw.f90 (338): Missing trnopt!=0 branch (irrelevant for trnopt=0)
- strsten.f90 (318): Missing sfcopt>=1 guard (no-op for sfcopt=1)
- timeflt.f90 (327): Missing tund/qasl/qt filters (kernel is DISABLED)

## Unsolved Mystery: Fix Introduced 0.125% Divergence
- OLD GPU (no guards/clamping/scaling) matched CPU within 0.0015%
- NEW GPU (correct guards/clamping/scaling) diverges 0.125% from CPU
- phvuvw nim1→nim2 index fix had NO effect (values identical to pre-fix)
- Divergence starts around step 37, grows to 0.125% by step 102
- OLD GPU's wrong phase speeds (unscaled, all components overwritten by phvbcuvw)
  produced results closer to CPU than correct phase speeds
- Possible causes: (1) different GPU kernel is the real source; (2) floating-point
  order differences in the new complex GPU code; (3) phvbcuvw GPU rewrite has subtle bug
- Next step: try enabling ALL kernels to test main 38% issue, or isolate by reverting fixes one at a time
