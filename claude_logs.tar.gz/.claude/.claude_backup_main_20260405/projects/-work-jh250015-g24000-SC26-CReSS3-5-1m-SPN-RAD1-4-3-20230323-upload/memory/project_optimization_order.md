---
name: Optimization phasing strategy
description: Cross-kernel optimizations (data directives, async, comm overlap) must wait until all OpenMP kernels are GPU-ported and validated
type: project
---

Cross-kernel optimizations (data directives, async, communication-computation overlap) are deferred until after all OpenMP kernel GPU porting is complete.

**Why:** These optimizations create inter-kernel dependencies that break the current per-kernel `#ifdef` isolation. If an undiscovered porting bug exists alongside an optimization bug, the two failure modes become entangled and binary search cannot isolate the cause. Also, validation currently uses only one test case — a latent porting bug might only manifest with different inputs, compounding the problem.

**How to apply:** 
1. Complete all OpenMP → OpenACC kernel porting first
2. Validate porting correctness across multiple test cases/input data
3. Only then apply cross-kernel optimizations (data directives, async, comm overlap, data structure changes)
4. At that point, GPU-vs-GPU bit-for-bit comparison becomes a reliable validation method for optimizations that don't change FP order
