# CReSS GPU Porting Project Memory

## Project Overview
- CReSS weather simulation: Fortran code porting from OpenMP (CPU) to OpenACC (GPU)
- Uses preprocessor guards: `#if defined(USE_GPU) && !defined(DISABLE_GPU_NNN)`
- 156 GPU kernels, per-kernel enable/disable via compile flags
- Instructions: `./Claude/instructions/main.md`, progress: `./Claude/instructions/progress/`

## Build System
- Build: `csh compile_radlib.csh solver compile.conf`
- Clean: `csh compile_radlib.csh clean` (needed when preprocessor flags change)
- Regular build handles source file changes via Make dependencies
- Job submit: `cd test_real && qsub MIYABI-solver.sh`
- Job status: `qstat <jobid>` (NOT `qstat -u`)

## Simulation Config (test_real/user.conf)
- trnopt=0, sfcopt=1, mfcopt=1, mpopt=0, advopt=3, cphopt=3
- wbc=ebc=sbc=nbc=7 (radiation BC)
- exbopt=11, exbvar='--x---xx'

## Key Bugs Found & Fixed
- See `debugging_notes.md` for 2026-02-27 patterns
- **2026-03-11: steptund.f90 (GPU_311)** — ss配列欠落バグ修正済み
- **2026-03-11: swp2nxt.f90 (GPU_321)** — advopt.le.3 コピペバグ修正済み
- **2026-03-18: more0q.f90 (GPU_204)** — sink式・nkループ欠落バグ修正済み（詳細下記）

## Compiler Flag Effect: VALIDATED (2026-03-05)
- `-acc -gpu=managed` flags do NOT cause significant numerical errors
- noacc vs gpudisabled: ppmax diff ~3.5e-7, ppmin diff ~1.3e-7, TKE diff ~2.0e-5
- `log.solver_gpudisabled.ref.txt` is the proper GPU baseline reference

## Bug Fix: steptund.f90 GPU_311 (2026-03-11) — RESOLVED
- GPU版のKernel 311で係数行列 `ss` 配列の更新が完全に欠落
- CPU版は `rr,ss,tt` 3配列設定、GPU版は `rr,tt` のみだった
- 未初期化ssがgaussel（Gaussian消去法）に渡り発散

## Bug Fix: swp2nxt.f90 GPU_321 (2026-03-11 session2) — RESOLVED
- GPU advopt.le.3ブランチで系統的コピペバグ
- CPU版: aerosol/tracer/TKE/tundは `past=future` のみ（3-way swapではない）
- GPU版: 全変数に3-way swap適用 → 4箇所修正 (qaslp, qtp, tkep, tundp)

## Bug Fix: more0q.f90 GPU_204 (2026-03-18) — RESOLVED
- バイナリサーチ（7ラウンド、156→1カーネル）で特定
- 5つのバグ: (1)nk>1ケース欠落 (2)evapor_optガード欠落
  (3)Rain sink式誤り(4項欠落) (4)Snow sink式誤り(符号反転+1項欠落)
  (5)Graupel sink式誤り(符号反転+3項欠落)
- 修正後: step60 tkemax差 2.12%→0.001%

## Bug Fix: phvbcs.f90 GPU_094 (2026-03-18 session3) — RESOLVED
- バイナリサーチ（6ラウンド）で特定
- GPU版でdtdvbスケーリングの `fproc(1:3)=='sml'` 条件が欠落
- CPU版: fproc=='sml'なら常にdtdvb適用、それ以外はadvopt>=4のみ
- GPU版: advopt>=4の時しか適用しない → advopt=3でスケーリング漏れ
- 4箇所の境界(west/east/south/north)すべてで同一バグ
- 修正後: ppmax差 -0.47%→0.000%

## Current Status (2026-03-18 session4) — 360stepフルテスト完了
- 全156 GPUカーネル有効、4つのバグ修正済み (311, 321, 204, 094)
- 60step精度: ppmax 0.000%, tkemax 0.001% (vs GPU disabled baseline)
- 360step精度: ppmax +0.0000%, tkemax -1.464% (FPU演算順序差による残差)
- 詳細: `progress/progress_2026-03-18_session3.md`

## Accuracy Test: 7 Benchmark-Failed Kernels (2026-03-17)
- 097,380,382,383,384,385,387を無効化して360stepテスト → 精度に実質差なし
- GPU vs CPU差はこれら7カーネルが原因ではない（FPU演算順序差）

## Reference Logs
- CPU reference (no -acc): `test_real/log.solver_noacc.ref.txt`
- GPU baseline (all disabled): `test_real/log.solver_gpudisabled.ref.txt`
- **fix204後全156有効(60step)**: `test_real/log.fix204.txt`
- **fix204後全156有効(360step)**: `test_real/log.fix204_full.txt`
- **fix094後全156有効(60step)**: `test_real/log.fix094.txt`
- **fix094後全156有効(360step)**: `test_real/log.fix094_full.txt`
- 修正前全156有効(360step): `test_real/log.fulltest_gpu_all.txt`

## Staggered Grid Index Pattern for Map Factor Clamping
- u grid: east=nim1, north=njm2 (rmf8u)
- v grid: east=nim2, north=njm1 (rmf8v)
- w/p grid: east=nim2, north=njm2 (rmf)

## Loop Bound Rules
- u,v components: generally `k=2,nk-2`
- w component (cell faces): `k=2,nk-1`
- Exception: u-west in phvuvw/phvbcuvw uses nk-1 for phase/clamp, nk-2 for dtsdb
- ALWAYS verify against CPU code - don't assume uniform bounds

## OpenACC Notes
- `!$acc kernels` / `!$acc end kernels` provides implicit synchronization
- No race conditions between separate `!$acc kernels` blocks
- Use `collapse(2)` for nested j/k or i/k loops
- Scalar temporaries auto-privatized in kernels regions

## Data Transfer Profiling
- [Unified Memory転送分析 (2026-03-23)](um_data_transfer_analysis.md)

## Optimization Strategy
- [最適化フェーズ方針](project_optimization_order.md) — cross-kernel最適化は全カーネル移植・検証完了後

## Experiments
- [Phase 3指示書アブレーション実験](project_instruction_ablation.md) — 指示書のどの要素がダンプ再実行防止・作業時間に効くかテスト

## Feedback
- [No binary files in commits](feedback_no_binary_commit.md) — exclude .bin/.ncu-rep from git commits by default
