---
name: Benchmark Failed 7 Kernels Accuracy Test
description: 2026-03-17 ベンチマーク全要素比較Failの7カーネル無効化テスト結果 — 精度に影響なし
type: project
---

## ベンチマーク全要素比較Failの7カーネル無効化テスト (2026-03-17)

### 対象カーネル
- 097 (eddyvis) — 乱流渦粘性係数計算
- 380 (vspdmp), 382 (vspqv), 383 (vsps), 384 (vsps0), 385 (vspuvw) — 出力関連
- 387 (xy2ll) — 座標変換

### テスト構成
- `compile.conf_disable_failed7`: 上記7カーネルを DISABLE_GPU_NNN で無効化
- 360step (1800秒) フルテスト実行
- ログ: `test_real/log.solver_disable_failed7.txt`

### 結果: 精度に実質的な差なし
| 指標 | AllEnabled vs CPU | 7Disabled vs CPU | AllEnabled vs 7Disabled |
|------|:-:|:-:|:-:|
| ppmax 最大差 | 5.77% (step310) | 5.77% (step310) | 0.0000% |
| ppmin 最大差 | 0.018% | 0.018% | 0.0001% |
| tkemax 最大差 | 12.04% (step190) | 12.02% (step190) | 0.12% (step191) |
| tkemax 最終step | 1.73% | 1.72% | 0.004% |

**Why:** ベンチマーク（単一ステップ）で全要素比較Failだった7カーネルが、時間積分シミュレーションの精度劣化の原因かどうかを検証するため。

**How to apply:** GPU vs CPU差（ppmax ~5.8%, tkemax ~12%）はこれら7カーネルが原因ではなく、浮動小数点演算順序差によるカオス的蓄積。7カーネルに特段の問題はない。ベンチマークのFail判定は単一ステップの厳密比較であり、シミュレーション精度への影響とは別問題。
