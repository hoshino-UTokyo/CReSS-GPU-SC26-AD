---
name: Phase 3 instruction ablation study design
description: Experiment to test which parts of Phase 3 instructions reduce completion time, especially preventing dump re-execution
type: project
---

## 目的

Phase 3（CPUベンチマーク作成）の指示書のどの要素が作業完了時間に効いているかをテストする。特にダンプ再実行を防ぐ要因の特定が重要。

## 実験スケール

1/10スケール: 15カーネル対象、シミュレーション36ステップ。

## バリアント設計（3パターン、確定）

| Variant | 指示内容 |
|---------|----------|
| A. Minimal | 目的 + テンプレート/チェックリスト |
| B. +Workflow | A + 3段階ワークフロー |
| C. Full | B + safety rules (inout判定 + condition列ルール) |

- テンプレート・チェックリストは全バリアント共通（Stage 3の効率差を排除、差分をStage 1〜2に絞る）
- progress report指示は全バリアント共通
- 30分で実験者が中断指示 → progress report作成

**Why:** C→D（テンプレート効果）の比較は不要。テンプレートを共通ベースラインにすることで、ワークフローとsafety rulesの効果をクリーンに分離。

## 分離したい要因

- A→B: ワークフロー構造の効果（カーネル毎ダンプ→一括ダンプ）
- B→C: safety rulesの効果（**最重要比較**）

## 15カーネル選定（確定）

Top 12 by runtime + condition必須3カーネル。
詳細: `Claude/paper/ablation_experiment/target_kernels.txt`

condition必須カーネル: 320_swadjst, 204_more0q, 331_totalqwi

## ファイル

`Claude/paper/ablation_experiment/` に格納:
- `README.md`, `variant_A_minimal.md`, `variant_B_workflow.md`, `variant_C_safety.md`
- `target_kernels.txt`

## TODO

- 各バリアント用の作業ディレクトリ準備
- 実験実行・記録
