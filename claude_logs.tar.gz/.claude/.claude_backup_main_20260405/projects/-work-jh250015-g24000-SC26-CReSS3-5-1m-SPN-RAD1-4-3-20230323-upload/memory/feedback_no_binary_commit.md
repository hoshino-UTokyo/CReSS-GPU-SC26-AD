---
name: No binary files in commits
description: User does not want binary files (e.g. .bin, .ncu-rep) included in git commits
type: feedback
---

Do not include binary files in git commits unless explicitly asked.

**Why:** User rejected a git add that included large binary files (test_real/result/*.bin etc.).

**How to apply:** When staging files for commit, exclude binary files (.bin, .ncu-rep, compiled executables) by default. Only add text/source files.
