########################################################################
# ISPACK FORTRAN SUBROUTINE LIBRARY FOR SCIENTIFIC COMPUTING
# Copyright (C) 1998--2015 Keiichi Ishioka <ishioka@gfd-dennou.org>
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
# 
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
# 02110-1301 USA.
########################################################################
.text
.globl ljlswg_
ljlswg_:
       movl   (%rdi), %edi  # : JH �� rdi ��
       vbroadcastsd (%rsi), %ymm0 # SR �� ymm0 ��4�ս��
       vbroadcastsd 8(%rsi), %ymm5 # SI �� ymm5 ��4�ս��
       vbroadcastsd (%rdx), %ymm1 # R �� ymm1 ��4�ս��
       movq  8(%rsp), %r10  # : WR �Υ١������ɥ쥹
       
       shlq $3,%rdi # JH*8 �� rdi ��
       xorq %rdx,%rdx
       subq %rdi,%rdx
       
       movq %r10,%r11
       addq %rdi,%r11  # : WI �Υ١������ɥ쥹
       
       subq %rdx,%r8
       subq %rdx,%r9
       subq %rdx,%r10
       subq %rdx,%r11                     
       subq %rdx,%rcx
       
.align 16
.L0:
       vmulpd (%rcx,%rdx),%ymm1,%ymm4 # Y*R	
       vmovapd (%r8,%rdx), %ymm2 # QA
       vmulpd %ymm2,%ymm4,%ymm4 # R*Y*QA
       vmulpd %ymm0,%ymm2,%ymm3 # SR*QA
       vmulpd %ymm5,%ymm2,%ymm2 # SI*QA
       vaddpd (%r9,%rdx),%ymm4,%ymm4 # �������줿 QB �� ymm4 ��
       vaddpd (%r10,%rdx),%ymm3,%ymm3 # �������줿 WR �� ymm3 ��
       vaddpd (%r11,%rdx),%ymm2,%ymm2 # �������줿 WI �� ymm2 ��	
       vmovapd %ymm4,(%r9,%rdx) # QB �򥻡���
       vmovapd %ymm3,(%r10,%rdx) # WR �򥻡���
       vmovapd %ymm2,(%r11,%rdx) # WI �򥻡���
       addq $32,%rdx
       jnz .L0
       
       ret
       
